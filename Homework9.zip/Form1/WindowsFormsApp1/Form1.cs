﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSup_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Suppliers was clicked");
        }

        private void btnDes_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Designs was clicked");
        }

        private void btnCat_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Categories was clicked");
        }
    }
}
