﻿CREATE TABLE [dbo].[Categories]
(
	[categoryID] INT NOT NULL PRIMARY KEY, 
    [categoryName] VARCHAR(20) NULL, 
    [categoryDescription] VARCHAR(150) NULL
)
