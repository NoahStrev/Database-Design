﻿CREATE TABLE [dbo].[Suppliers]
(
	[supplierID] INT NOT NULL PRIMARY KEY, 
    [supplierName] VARCHAR(20) NULL, 
    [supplierFaxNumber] VARCHAR(10) NULL
)
